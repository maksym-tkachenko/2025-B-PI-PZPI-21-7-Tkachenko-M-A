﻿using Accounting.DAL.UnitOfWork;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace Accounting.BLL.Services.Hosted
{
    public class MidnightService : IHostedService, IDisposable
    {
        private readonly IServiceProvider _serviceProvider;
        private Timer? _timer = null;

        public MidnightService(IServiceProvider serviceProvider)
        {
            _serviceProvider = serviceProvider;
        }

        public Task StartAsync(CancellationToken token)
        {
            Execute();

            DateTime now = DateTime.Now;
            DateTime todayMidnight = now.AddDays(1).Date;
            var dueTime = todayMidnight - now;
            _timer = new Timer(Execute, null, dueTime, TimeSpan.FromDays(1));
            return Task.CompletedTask;
        }

        public Task StopAsync(CancellationToken stoppingToken)
        {
            _timer?.Change(Timeout.Infinite, 0);
            return Task.CompletedTask;
        }

        public void Dispose() => _timer?.Dispose();

        private void Execute(object? obj = null)
        {
            try
            {
                using (IServiceScope scope = _serviceProvider.CreateScope())
                {
                    var unitOfWork = scope.ServiceProvider.GetRequiredService<IUnitOfWork>();
                    Task.Run(async () => await ST.ReloadCatalogsAsync(unitOfWork));
                }
            }
            catch (Exception ex)
            {
            }
        }
    }
}
