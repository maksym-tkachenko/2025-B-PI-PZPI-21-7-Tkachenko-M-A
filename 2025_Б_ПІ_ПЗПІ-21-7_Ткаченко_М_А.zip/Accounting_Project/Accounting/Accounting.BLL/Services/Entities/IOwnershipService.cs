﻿using Accounting.BLL.Models.Business.Common;
using Accounting.BLL.Models.Filters;
using Accounting.DAL.Entities;

namespace Accounting.BLL.Services.Entities
{
    public interface IOwnershipService
    {
        Task<ItemsList<Ownership>> FindByFilterAsync(OwnershipFilter filter);

        Task<Ownership> CreateAsync(Ownership ownership);

        Task<Ownership> UpdateAsync(Ownership ownership);

        Task<Ownership> SaveAsync(Ownership ownership);

        Task<Ownership> FindByIdAsync(int id);

        Task<Ownership> DeleteAsync(int id);
    }
}
