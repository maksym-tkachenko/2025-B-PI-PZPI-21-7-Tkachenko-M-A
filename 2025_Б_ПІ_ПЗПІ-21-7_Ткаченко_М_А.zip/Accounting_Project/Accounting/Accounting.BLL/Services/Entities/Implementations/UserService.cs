﻿using Accounting.BLL.Models.Business.Common;
using Accounting.BLL.Models.Filters;
using Accounting.BLL.Services.Entities.Implementations.Common;
using Accounting.DAL.Entities.Identity;
using Accounting.DAL.Repositories;
using Accounting.DAL.UnitOfWork;

namespace Accounting.BLL.Services.Entities.Implementations
{
    public class UserService : BaseService<User, IRepository<User>>, IUserService
    {
        public UserService(IUnitOfWork unitOfWork)
            : base(unitOfWork)
        {
        }

        public async Task<ItemsList<User>> FindByFilterAsync(UserFilter filter)
        {
            return await base.FindByFilterAsync(filter);
        }
    }
}
