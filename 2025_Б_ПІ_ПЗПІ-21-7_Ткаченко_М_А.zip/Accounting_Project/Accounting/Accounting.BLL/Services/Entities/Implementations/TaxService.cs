﻿using Accounting.BLL.Models.Business.Common;
using Accounting.BLL.Models.Filters;
using Accounting.BLL.Services.Entities.Implementations.Common;
using Accounting.DAL.Entities;
using Accounting.DAL.Repositories;
using Accounting.DAL.UnitOfWork;

namespace Accounting.BLL.Services.Entities.Implementations
{
    class TaxService : BaseService<Tax, IRepository<Tax>>, ITaxService
    {
        public TaxService(IUnitOfWork unitOfWork)
            : base(unitOfWork)
        {
        }

        public async Task<ItemsList<Tax>> FindByFilterAsync(TaxFilter filter)
        {
            return await base.FindByFilterAsync(filter);
        }
    }
}
