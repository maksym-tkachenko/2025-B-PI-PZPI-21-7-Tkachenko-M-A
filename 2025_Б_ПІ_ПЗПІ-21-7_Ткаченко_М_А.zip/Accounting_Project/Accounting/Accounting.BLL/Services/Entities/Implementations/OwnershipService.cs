﻿using Accounting.BLL.Models.Business.Common;
using Accounting.BLL.Models.Filters;
using Accounting.BLL.Services.Entities.Implementations.Common;
using Accounting.DAL.Entities;
using Accounting.DAL.Repositories;
using Accounting.DAL.UnitOfWork;

namespace Accounting.BLL.Services.Entities.Implementations
{
    class OwnershipService : BaseService<Ownership, IRepository<Ownership>>, IOwnershipService
    {
        public OwnershipService(IUnitOfWork unitOfWork)
            : base(unitOfWork)
        {
        }

        public async Task<ItemsList<Ownership>> FindByFilterAsync(OwnershipFilter filter)
        {
            return await base.FindByFilterAsync(filter);
        }
    }
}
