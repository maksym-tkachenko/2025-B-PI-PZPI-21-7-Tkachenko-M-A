﻿using Accounting.BLL.Models.Business.Common;
using Accounting.BLL.Models.Filters;
using Accounting.DAL.Entities;

namespace Accounting.BLL.Services.Entities
{
    public interface IEnterpriseService
    {
        Task<ItemsList<Enterprise>> FindByFilterAsync(EnterpriseFilter filter);

        Task<Enterprise> CreateAsync(Enterprise enterprise);

        Task<Enterprise> UpdateAsync(Enterprise enterprise);

        Task<Enterprise> SaveAsync(Enterprise enterprise);

        Task<Enterprise> FindByIdAsync(int id);

        Task<Enterprise> DeleteAsync(int id);
    }
}
