﻿using Accounting.BLL.Models.Business.Common;
using Accounting.BLL.Models.Filters;
using Accounting.DAL.Entities;

namespace Accounting.BLL.Services.Entities
{
    public interface ITaxService
    {
        Task<ItemsList<Tax>> FindByFilterAsync(TaxFilter filter);

        Task<Tax> CreateAsync(Tax tax);

        Task<Tax> UpdateAsync(Tax tax);

        Task<Tax> SaveAsync(Tax tax);

        Task<Tax> FindByIdAsync(int id);

        Task<Tax> DeleteAsync(int id);
    }
}
