﻿using Accounting.BLL.Models.Business.Common;
using Accounting.BLL.Models.Filters;
using Accounting.DAL.Entities.Identity;

namespace Accounting.BLL.Services.Entities
{
    public interface IUserService
    {
        Task<ItemsList<User>> FindByFilterAsync(UserFilter filter);

        Task<User> CreateAsync(User user);

        Task<User> UpdateAsync(User user);

        Task<User> DeleteAsync(int id);
    }
}
