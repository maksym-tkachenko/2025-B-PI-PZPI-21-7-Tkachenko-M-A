﻿namespace Accounting.BLL.Models.Charts.Settings
{
    public class GroupedBarChartSettings
    {
        public double Height { get; set; }

        public double YaxisLabelsMaxWidth { get; set; } = 160;
    }
}
