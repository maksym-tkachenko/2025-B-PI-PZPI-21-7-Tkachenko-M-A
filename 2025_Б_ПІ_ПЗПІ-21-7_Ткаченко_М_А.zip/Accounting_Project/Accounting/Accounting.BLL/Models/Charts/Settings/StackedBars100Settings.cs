﻿namespace Accounting.BLL.Models.Charts.Settings
{
    public class StackedBars100Settings
    {
        public string Title = string.Empty;

        public string Direction { get; set; } = string.Empty;

        public double Height { get; set; }

        public double YaxisLabelsMaxWidth { get; set; } = 160;
    }
}
