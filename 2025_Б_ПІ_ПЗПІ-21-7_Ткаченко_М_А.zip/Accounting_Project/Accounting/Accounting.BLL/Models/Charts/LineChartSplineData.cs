﻿namespace Accounting.BLL.Models.Charts
{
    public class LineChartSplineData
    {
        public string Name { get; set; } = null!;

        public List<decimal> Data { get; set; } = null!;

        public LineChartSplineData()
        {
            Name = string.Empty;
            Data = new List<decimal>();
        }
    }
}
