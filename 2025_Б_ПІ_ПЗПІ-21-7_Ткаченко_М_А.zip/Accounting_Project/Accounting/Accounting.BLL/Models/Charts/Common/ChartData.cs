﻿namespace Accounting.BLL.Models.Charts.Common
{
    public class ChartData<TData>
    {
        public List<TData> Series { get; set; }

        public List<string> Categories { get; set; }

        public ChartData()
        {
            Series = new();
            Categories = new();
        }

        public bool IsDefault()
        {
            return Series.Count == 0 && Categories.Count == 0;
        }
    }
}
