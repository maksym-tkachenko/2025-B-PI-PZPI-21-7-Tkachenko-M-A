﻿namespace Accounting.BLL.Models.Charts
{
    public class ChartGroupedBarData
    {
        public string Name { get; set; } = null!;

        public string Type { get; set; } = null!;

        public List<decimal> Data { get; set; } = null!;

        public ChartGroupedBarData()
        {
            Name = string.Empty;
            Type = string.Empty;
            Data = new List<decimal>();
        }

        public ChartGroupedBarData(string name, string type)
        {
            Name = name;
            Type = type;
            Data = new List<decimal>();
        }
    }
}
