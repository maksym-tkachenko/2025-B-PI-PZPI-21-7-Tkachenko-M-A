﻿using Accounting.DAL.Entities;

namespace Accounting.BLL.Models.Business
{
    public class EnterpriseInfo
    {
        public Enterprise Enterprise { get; private set; }

        public List<OwnershipInfo> OwnershipInfos => Enterprise.Ownerships.Select(o => new OwnershipInfo(o)).ToList();

        public decimal AmortizationDeductions => OwnershipInfos.Sum(o => (decimal?)o.AmortizationDeductions) ?? 0;

        public decimal TaxesPaid => OwnershipInfos.Sum(o => (decimal?)o.TaxesPaid) ?? 0;

        public decimal InitialCost => OwnershipInfos.Sum(o => (decimal?)o.Ownership.InitialCost) ?? 0;

        public decimal CurrentCost => OwnershipInfos.Sum(o => (decimal?)o.CurrentCost) ?? 0;

        public decimal LostCostPercent
        {
            get
            {
                if (CurrentCost == 0 || InitialCost == 0)
                {
                    return 0;
                }

                return 100 - CurrentCost / InitialCost * 100;
            }
        }

        public EnterpriseInfo(Enterprise enterprise)
        {
            Enterprise = enterprise;
        }
    }
}
