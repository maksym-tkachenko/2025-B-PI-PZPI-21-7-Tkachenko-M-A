﻿using Accounting.BLL.Models.Filters.Common;

namespace Accounting.BLL.Models.Business.Common
{
    public class ItemsList<T> where T : class
    {
        public int PageNumber { get; private set; }

        public int PageSize { get; private set; }

        public List<T> Items { get; set; }

        public int TotalItems { get; set; }

        public int TotalPages
        {
            get
            {
                if (TotalItems == 0 || PageSize == 0)
                {
                    return 0;
                }

                return (int)Math.Ceiling((decimal)TotalItems / PageSize);
            }
        }

        private ItemsList(int pageNumber, int pageSize, int totalItems)
        {
            PageNumber = pageNumber;
            PageSize = pageSize;
            TotalItems = totalItems;
            Items = new List<T>();
        }

        public ItemsList()
            : this(0, 0, 0)
        {
        }

        public ItemsList(BaseFilter filter)
            : this(filter.PageNumber, filter.PageSize, 0)
        {
        }
    }
}
