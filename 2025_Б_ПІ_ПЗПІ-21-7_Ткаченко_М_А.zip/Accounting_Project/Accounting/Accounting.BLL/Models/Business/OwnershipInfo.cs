﻿using Accounting.DAL.Entities;
using Accounting.DAL.Entities.Enums;

namespace Accounting.BLL.Models.Business
{
    public class OwnershipInfo
    {
        public Ownership Ownership { get; private set; } = null!;

        public decimal AmortizationDeductions
        {
            get
            {
                int periodsCount = (int)(DateTime.Now - Ownership.Commissioning).TotalDays;

                switch (Ownership.Period)
                {
                    case Period.Month: periodsCount /= 30; break;
                    case Period.Year: periodsCount /= 365; break;
                }

                return periodsCount * Ownership.LossOfPriceByPeriod;
            }
        }

        public decimal TaxesPaid
        {
            get
            {
                int periodsCount = (int)(DateTime.Now - Ownership.Commissioning).TotalDays;

                switch (Ownership.Period)
                {
                    case Period.Month: periodsCount /= 30; break;
                    case Period.Year: periodsCount /= 365; break;
                }

                if (Ownership.Tax.Type == TaxType.Fixed)
                {
                    return periodsCount * Ownership.Tax.Value;
                }

                if (Ownership.Tax.Type == TaxType.Percent)
                {
                    return Ownership.InitialCost / 100 * Ownership.Tax.Value * periodsCount;
                }

                return 0;
            }
        }

        public decimal CurrentCost => Ownership.InitialCost - TaxesPaid - AmortizationDeductions;

        public decimal LostCostPercent
        {
            get
            {
                if (CurrentCost == 0 || Ownership.InitialCost == 0)
                {
                    return 0;
                }

                return 100 - CurrentCost / Ownership.InitialCost * 100;
            }
        }

        public OwnershipInfo(Ownership ownership)
        {
            Ownership = ownership;
        }
    }
}
