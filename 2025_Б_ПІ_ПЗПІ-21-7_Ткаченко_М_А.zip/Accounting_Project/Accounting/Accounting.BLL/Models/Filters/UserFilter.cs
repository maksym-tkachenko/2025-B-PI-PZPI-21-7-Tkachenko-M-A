﻿using Accounting.BLL.Filters.Common;
using Accounting.DAL.Entities.Identity;

namespace Accounting.BLL.Models.Filters
{
    public class UserFilter : ExpressionFilter<User>
    {
        public string? SearchPhrase { get; set; }

        public string? Role { get; set; }

        public override QueryExpressions<User> QueryExpressions
        {
            get
            {
                var expressions = base.QueryExpressions;

                if (!string.IsNullOrEmpty(SearchPhrase))
                {
                    string phrase = SearchPhrase.ToLower();
                    expressions.Add(u => u.Email.ToLower().Contains(phrase));
                }

                if (!string.IsNullOrEmpty(Role))
                {
                    expressions.Add(u => u.UserRoles.Any(ur => ur.Role.Name == Role));
                }

                return expressions;
            }
        }
    }
}
