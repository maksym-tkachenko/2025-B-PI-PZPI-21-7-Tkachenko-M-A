﻿using Accounting.BLL.Filters.Common;
using Accounting.DAL.Entities;

namespace Accounting.BLL.Models.Filters
{
    public class TaxFilter : ExpressionFilter<Tax>
    {
    }
}
