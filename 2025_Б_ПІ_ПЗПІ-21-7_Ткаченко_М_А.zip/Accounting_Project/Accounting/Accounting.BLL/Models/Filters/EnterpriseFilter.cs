﻿using Accounting.BLL.Filters.Common;
using Accounting.DAL.Entities;

namespace Accounting.BLL.Models.Filters
{
    public class EnterpriseFilter : ExpressionFilter<Enterprise>
    {
        public int? UserId { get; set; }

        public override QueryExpressions<Enterprise> QueryExpressions
        {
            get
            {
                var expressions = base.QueryExpressions;

                if (UserId.HasValue)
                {
                    expressions.Add(e => e.UserId == UserId.Value);
                }

                return expressions;
            }
        }
    }
}
