﻿namespace Accounting.BLL.Models.Filters.Common
{
    public enum OrderType
    {
        Ascending = 0,
        Descending = 1
    }
}
