﻿using Accounting.BLL.Filters.Common;
using Accounting.DAL.Entities;

namespace Accounting.BLL.Models.Filters
{
    public class OwnershipFilter : ExpressionFilter<Ownership>
    {
        public int? UserId { get; set; }

        public override QueryExpressions<Ownership> QueryExpressions
        {
            get
            {
                var expressions = base.QueryExpressions;

                if (UserId.HasValue)
                {
                    expressions.Add(e => e.Enterprise.UserId == UserId.Value);
                }

                return expressions;
            }
        }
    }
}
