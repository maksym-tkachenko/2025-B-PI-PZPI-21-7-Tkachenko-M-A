using Accounting.DAL.Entities.Identity;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System.Security.Claims;

namespace Accounting.BLL.Managers
{
    public class UserManager : UserManager<User>
    {
        private readonly RoleManager _roleManager;

        private bool _isBusy;
        private User CurrentUser = null!;

        public UserManager(
            IUserStore<User> store,
            IOptions<IdentityOptions> optionsAccessor,
            IPasswordHasher<User> passwordHasher,
            IEnumerable<IUserValidator<User>> userValidators,
            IEnumerable<IPasswordValidator<User>> passwordValidators,
            ILookupNormalizer keyNormalizer,
            IdentityErrorDescriber errors,
            IServiceProvider services,
            ILogger<UserManager<User>> logger,
            RoleManager roleManager)
            : base(store, optionsAccessor, passwordHasher, userValidators, passwordValidators, keyNormalizer, errors, services, logger)
        {
            _roleManager = roleManager;
            _isBusy = false;
        }

        public new async Task<IdentityResult> ValidatePasswordAsync(User user, string password)
        {
            try
            {
                await WaitForPreviousOperationFinishAsync();
                _isBusy = true;
                var result = await base.ValidatePasswordAsync(user, password);
                _isBusy = false;
                return result;
            }
            catch (Exception ex)
            {
                _isBusy = false;
                throw;
            }
        }

        public override async Task<User> GetUserAsync(ClaimsPrincipal principal)
        {
            try
            {
                await WaitForPreviousOperationFinishAsync();

                if (CurrentUser == null)
                {
                    _isBusy = true;
                    CurrentUser = await base.GetUserAsync(principal);
                    _isBusy = false;
                }

                return CurrentUser;
            }
            catch (Exception ex)
            {
                _isBusy = false;
                throw;
            }
        }

        public override async Task<bool> IsInRoleAsync(User user, string role)
        {
            try
            {
                await WaitForPreviousOperationFinishAsync();
                _isBusy = true;
                bool result = await base.IsInRoleAsync(user, role);
                _isBusy = false;
                return result;
            }
            catch (Exception ex)
            {
                _isBusy = false;
                throw;
            }
        }

        public async Task<string> GetRoleAsync(User user)
        {
            try
            {
                await WaitForPreviousOperationFinishAsync();
                _isBusy = true;
                var roles = await GetRolesAsync(user);
                _isBusy = false;
                return roles.FirstOrDefault() ?? string.Empty;
            }
            catch (Exception ex)
            {
                _isBusy = false;
                throw;
            }
        }

        public async Task SetRoleAsync(User user, string newRole)
        {
            try
            {
                await WaitForPreviousOperationFinishAsync();
                _isBusy = true;
                var roles = await GetRolesAsync(user);
                await RemoveFromRolesAsync(user, roles);

                if (!string.IsNullOrEmpty(newRole) && await _roleManager.RoleExistsAsync(newRole))
                {
                    await AddToRoleAsync(user, newRole);
                }
                _isBusy = false;
            }
            catch (Exception ex)
            {
                _isBusy = false;
                throw;
            }
        }

        public override async Task<bool> HasPasswordAsync(User user)
        {
            try
            {
                await WaitForPreviousOperationFinishAsync();
                _isBusy = true;
                bool result = await base.HasPasswordAsync(user);
                _isBusy = false;
                return result;
            }
            catch (Exception ex)
            {
                _isBusy = false;
                throw;
            }
        }

        public override async Task<IdentityResult> RemovePasswordAsync(User user)
        {
            try
            {
                await WaitForPreviousOperationFinishAsync();
                _isBusy = true;
                var result = await base.RemovePasswordAsync(user);
                _isBusy = false;
                return result;
            }
            catch (Exception ex)
            {
                _isBusy = false;
                throw;
            }
        }

        public override async Task<IdentityResult> AddPasswordAsync(User user, string password)
        {
            try
            {
                await WaitForPreviousOperationFinishAsync();
                _isBusy = true;
                var result = await base.AddPasswordAsync(user, password);
                _isBusy = false;
                return result;
            }
            catch (Exception ex)
            {
                _isBusy = false;
                throw;
            }
        }

        private async Task WaitForPreviousOperationFinishAsync()
        {
            while (_isBusy)
            {
                await Task.Delay(50);
                if (!_isBusy) break;
            }

            await Task.CompletedTask;
        }
    }
}
