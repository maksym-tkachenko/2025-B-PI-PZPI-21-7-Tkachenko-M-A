﻿using Accounting.DAL.Entities;
using Accounting.DAL.UnitOfWork;

namespace Accounting.BLL.Infrastructure
{
    public static class ST
    {
        private static List<Catalog> _catalogs = new();

        public static Task ReloadCatalogsAsync(IUnitOfWork unitOfWork)
        {
            return Task.CompletedTask;
            //_catalogs = await unitOfWork.Catalogs.GetAllAsync();
        }
    }
}
