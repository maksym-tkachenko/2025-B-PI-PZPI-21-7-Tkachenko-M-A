﻿using Accounting.BLL.Managers;
using Accounting.BLL.Services.Entities;
using Accounting.BLL.Services.Entities.Implementations;
using Accounting.BLL.Services.Hosted;
using Accounting.DAL.Infrastructure;
using AutoMapper;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.DependencyInjection;

namespace Accounting.BLL.Infrastructure
{
    public static class DependencyInjections
    {
        public static IdentityBuilder ConfigureBLL(this IServiceCollection services, string connectionString)
        {
            return services.AddServices()
                .AddAutoMapper()
                .ConfigureDAL(connectionString)
                .AddManages();
        }

        public static void AddHostedServices(this IServiceCollection services)
        {
            services.AddHostedService<MidnightService>();
        }

        private static IServiceCollection AddServices(this IServiceCollection services)
        {
            return services
                .AddTransient<IEnterpriseService, EnterpriseService>()
                .AddTransient<IOwnershipService, OwnershipService>()
                .AddTransient<ITaxService, TaxService>()
                .AddTransient<IUserService, UserService>();
        }

        private static IdentityBuilder AddManages(this IdentityBuilder identityBuilder)
        {
            return identityBuilder
                .AddUserManager<UserManager>()
                .AddRoleManager<RoleManager>()
                .AddSignInManager<SignInManager>();
        }

        private static IServiceCollection AddAutoMapper(this IServiceCollection services)
        {
            return services.AddSingleton(provider => new MapperConfiguration(mapperConfig =>
            {
                //mapperConfig.AddProfile(new ApiMappingProfile());
            }).CreateMapper());
        }
    }
}
