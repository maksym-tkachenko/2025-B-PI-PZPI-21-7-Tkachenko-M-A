﻿using Accounting.BLL.Services.Entities;
using Accounting.Components;
using Accounting.DAL.Entities;
using Microsoft.AspNetCore.Components;

namespace Accounting.Pages.Taxes
{
    public class TaxFormComponent : NotificationComponent
    {
        [Inject] public ITaxService TaxService { get; set; } = null!;
        [Parameter] public int? Id { get; set; }

        public Tax Model { get; set; } = new();

        public async Task OnSaveAsync()
        {
            try
            {
                Model = await TaxService.SaveAsync(Model);
                AddSuccess("Успішно збережено");
                NavigationManager.NavigateTo("/taxes", true);
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }

        protected override async Task OnInitializedAsync()
        {
            try
            {
                var currentUser = await GetCurrentUserAsync();
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }

        protected override async Task OnParametersSetAsync()
        {
            try
            {
                if (Id.HasValue)
                {
                    Model = await TaxService.FindByIdAsync(Id.Value);
                }
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }
    }
}
