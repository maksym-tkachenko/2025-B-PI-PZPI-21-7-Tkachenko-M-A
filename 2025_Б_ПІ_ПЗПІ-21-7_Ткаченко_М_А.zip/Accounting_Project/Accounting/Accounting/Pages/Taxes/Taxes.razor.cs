﻿using Accounting.BLL.Models.Filters;
using Accounting.BLL.Services.Entities;
using Accounting.Components;
using Accounting.DAL.Entities;
using Microsoft.AspNetCore.Components;

namespace Accounting.Pages.Taxes
{
    public class TaxesComponent : ItemsListComponent<Tax, TaxFilter>
    {
        [Inject] public ITaxService TaxService { get; set; } = null!;

        public TaxesComponent()
            : base("Податки")
        {
        }

        protected override async Task OnInitializedAsync()
        {
            try
            {
                _currentUser = await GetCurrentUserAsync();
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }

        protected override async Task LoadItemsAsync()
        {
            try
            {
                ItemsList = await TaxService.FindByFilterAsync(Filter);
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }

        public async Task OnDeleteAsync(int id)
        {
            try
            {
                await TaxService.DeleteAsync(id);
                await LoadItemsAsync();
                AddSuccess("Успішно видалено!");
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }
    }
}
