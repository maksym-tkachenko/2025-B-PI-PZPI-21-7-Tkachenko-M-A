﻿using Accounting.BLL.Models.Filters;
using Accounting.BLL.Services.Entities;
using Accounting.Components;
using Accounting.DAL.Entities;
using Accounting.DAL.Entities.Constants;
using Microsoft.AspNetCore.Components;

namespace Accounting.Pages.Ownerships
{
    public class OwnershipsComponent : ItemsListComponent<Ownership, OwnershipFilter>
    {
        [Inject] public IOwnershipService OwnershipService { get; set; } = null!;

        public OwnershipsComponent()
            : base("Власності")
        {
        }

        protected override async Task OnInitializedAsync()
        {
            try
            {
                _currentUser = await GetCurrentUserAsync();
                string currentRole = await UserManager.GetRoleAsync(_currentUser);

                if (currentRole == Roles.User)
                {
                    Filter.UserId = _currentUser.Id;
                }
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }

        protected override async Task LoadItemsAsync()
        {
            try
            {
                ItemsList = await OwnershipService.FindByFilterAsync(Filter);
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }

        public async Task OnDeleteAsync(int id)
        {
            try
            {
                await OwnershipService.DeleteAsync(id);
                await LoadItemsAsync();
                AddSuccess("Успішно видалено!");
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }
    }
}
