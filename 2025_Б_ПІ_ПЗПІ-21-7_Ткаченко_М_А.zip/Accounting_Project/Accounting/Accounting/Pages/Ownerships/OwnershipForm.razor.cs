﻿using Accounting.BLL.Models.Filters;
using Accounting.BLL.Services.Entities;
using Accounting.Components;
using Accounting.DAL.Entities.Constants;
using Accounting.DAL.Entities.Identity;
using Accounting.DAL.Entities;
using Microsoft.AspNetCore.Components;

namespace Accounting.Pages.Ownerships
{
    public class OwnershipFormComponent : NotificationComponent
    {
        [Inject] public IOwnershipService OwnershipService { get; set; } = null!;
        [Inject] public IUserService UserService { get; set; } = null!;
        [Inject] public IEnterpriseService EnterpriseService { get; set; } = null!;
        [Inject] public ITaxService TaxService { get; set; } = null!;
        [Parameter] public int? Id { get; set; }

        public Ownership Model { get; set; } = new();

        public List<User> Users { get; set; } = new();
        public List<Enterprise> Enterprises { get; set; } = new();
        public List<Tax> Taxes { get; set; } = new();

        private EnterpriseFilter EnterpriseFilter { get; set; } = new EnterpriseFilter()
        {
            PageSize = int.MaxValue
        };

        private UserFilter UserFilter { get; set; } = new UserFilter()
        {
            Role = Roles.User,
            PageSize = int.MaxValue
        };

        public async Task OnSaveAsync()
        {
            try
            {
                Model = await OwnershipService.SaveAsync(Model);
                AddSuccess("Успішно збережено");
                NavigationManager.NavigateTo("/ownerships", true);
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }

        public async Task OnChangeUserAsync(int userId)
        {
            EnterpriseFilter.UserId = userId;
            Enterprises = (await EnterpriseService.FindByFilterAsync(EnterpriseFilter)).Items;
        }

        protected override async Task OnInitializedAsync()
        {
            try
            {
                var currentUser = await GetCurrentUserAsync();
                var currentRole = await UserManager.GetRoleAsync(currentUser);

                if (Roles.Admin == currentRole)
                {
                    Users = (await UserService.FindByFilterAsync(UserFilter)).Items;
                }
                else
                {
                    EnterpriseFilter.UserId = currentUser.Id;
                }

                Enterprises = (await EnterpriseService.FindByFilterAsync(EnterpriseFilter)).Items;

                var taxFilter = new TaxFilter();
                taxFilter.PageSize = int.MaxValue;
                Taxes = (await TaxService.FindByFilterAsync(taxFilter)).Items;
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }

        protected override async Task OnParametersSetAsync()
        {
            try
            {
                if (Id.HasValue)
                {
                    Model = await OwnershipService.FindByIdAsync(Id.Value);
                }
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }
    }
}
