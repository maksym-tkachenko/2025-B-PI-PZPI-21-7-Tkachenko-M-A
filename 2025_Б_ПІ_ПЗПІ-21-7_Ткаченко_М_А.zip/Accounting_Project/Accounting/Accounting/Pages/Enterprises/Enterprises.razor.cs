﻿using Accounting.BLL.Models.Filters;
using Accounting.BLL.Services.Entities;
using Accounting.Components;
using Accounting.DAL.Entities;
using Accounting.DAL.Entities.Constants;
using Microsoft.AspNetCore.Components;

namespace Accounting.Pages.Enterprises
{
    public class EnterprisesComponent : ItemsListComponent<Enterprise, EnterpriseFilter>
    {
        [Inject] public IEnterpriseService EnterpriseService { get; set; } = null!;

        public EnterprisesComponent()
            : base("Підприємства")
        {
        }

        protected override async Task OnInitializedAsync()
        {
            try
            {
                _currentUser = await GetCurrentUserAsync();
                string currentRole = await UserManager.GetRoleAsync(_currentUser);

                if (currentRole == Roles.User)
                {
                    Filter.UserId = _currentUser.Id;
                }
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }

        protected override async Task LoadItemsAsync()
        {
            try
            {
                ItemsList = await EnterpriseService.FindByFilterAsync(Filter);
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }

        public async Task OnDeleteAsync(int id)
        {
            try
            {
                await EnterpriseService.DeleteAsync(id);
                await LoadItemsAsync();
                AddSuccess("Успішно видалено!");
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }
    }
}
