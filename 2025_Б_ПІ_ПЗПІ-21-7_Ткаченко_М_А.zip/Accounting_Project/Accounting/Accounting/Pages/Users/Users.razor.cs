﻿using Accounting.BLL.Managers;
using Accounting.BLL.Models.Filters;
using Accounting.BLL.Services.Entities;
using Accounting.Components;
using Accounting.DAL.Entities.Identity;
using Microsoft.AspNetCore.Components;

namespace Accounting.Pages.Users
{
    public enum EditType
    {
        None, ChangeRole, EditProfile, ChangePassword
    }

    public class UsersModel : ItemsListComponent<User, UserFilter>
    {
        private Dictionary<int, string> _userRoles;

        [Inject] private IUserService UserService { get; set; } = null!;

        public User? SelectedUser { get; private set; }
        public EditType EditType { get; private set; }

        public UsersModel()
            : base("Користувачі")
        {
            _userRoles = new();
            EditType = EditType.None;
        }

        public string GetRoleName(int userId)
        {
            if (_userRoles.ContainsKey(userId))
            {
                return _userRoles[userId];
            }

            return string.Empty;
        }

        public Task OpenModal(EditType editType, User? user = null)
        {
            EditType = editType;
            SelectedUser = user;
            return Task.CompletedTask;
        }

        public Task OnRoleChanged(string newRole)
        {
            if (SelectedUser != null)
            {
                _userRoles[SelectedUser.Id] = newRole;
            }

            SelectedUser = null;
            return CloseModalAsync();
        }

        public async Task OnUsetChanged(User user)
        {
            await LoadItemsAsync();
            await CloseModalAsync();
        }
        
        public async Task OnPasswordChangedAsync()
        {
            try
            {
                SelectedUser = null;
                await CloseModalAsync();
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }

        public Task OnCancelModal()
        {
            EditType = EditType.None;
            SelectedUser = null;
            return Task.CompletedTask;
        }

        protected override void OnInitialized()
        {
            try
            {
                Title = "Користувачі";
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }

        protected override async Task LoadItemsAsync()
        {
            try
            {
                ItemsList = await UserService.FindByFilterAsync(Filter);
                _userRoles = await GetUserRolesAsync(ItemsList.Items);
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }

        private async Task<Dictionary<int, string>> GetUserRolesAsync(List<User> users)
        {
            try
            {
                Dictionary<int, string> userRoles = new();
                foreach (var user in users)
                {
                    userRoles.Add(user.Id, await UserManager.GetRoleAsync(user));
                }

                return userRoles;
            }
            catch (Exception ex)
            {
                AddError(ex);
                throw;
            }
        }

        private async Task CloseModalAsync()
        {
            try
            {
                EditType = EditType.None;
                await JsRuntime.CloseModalAsync(EditType.ToString());
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }
    }
}
