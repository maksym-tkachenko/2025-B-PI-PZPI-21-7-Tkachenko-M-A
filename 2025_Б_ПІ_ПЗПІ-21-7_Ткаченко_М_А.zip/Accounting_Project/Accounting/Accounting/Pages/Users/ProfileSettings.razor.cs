﻿using Accounting.BLL.Services.Entities;
using Accounting.Components;
using Accounting.DAL.Entities.Identity;
using Microsoft.AspNetCore.Components;

namespace Accounting.Pages.Users
{
    public class ProfileSettingsModel : NotificationComponent
    {
        [Inject] private IUserService UserService { get; set; } = null!;

        public User User { get; set; } = new();

        public ProfileSettingsModel()
            : base("Користувач")
        {
        }

        protected override async Task OnInitializedAsync()
        {
            try
            {
                Title = "Налаштування";
                User = await GetCurrentUserAsync();
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }
    }
}
