﻿using Accounting.BLL.Managers;
using Accounting.BLL.Services.Entities;
using Accounting.Components;
using Accounting.DAL.Entities.Identity;
using Accounting.Infrastructure;
using Microsoft.AspNetCore.Components;

namespace Accounting.Pages.Users.Modals
{
    public class ChangeRoleModel : NotificationComponent
    {
        [Inject] public RoleManager RoleManager { get; set; } = null!;
        [Inject] public IUserService UserService { get; set; } = null!;

        [Parameter] public User User { get; set; } = null!;
        [Parameter] public EventCallback<string> OnRoleChanged { get; set; }

        public List<string> Roles { get; private set; }
        public string CurrentRole { get; private set; }
        public string SelectedRole { get; set; }

        public ChangeRoleModel()
            : base("Зміна ролі")
        {
            Roles = DAL.Entities.Constants.Roles.AllRoles;
            CurrentRole = string.Empty;
            SelectedRole = string.Empty;
        }

        protected override async Task OnParametersSetAsync()
        {
            try
            {
                CurrentRole = await UserManager.GetRoleAsync(User);
                SelectedRole = CurrentRole;
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }

        public async Task SaveRoleAsync()
        {
            try
            {
                AddInfo("Роль змінюється...");
                User = await UserManager.FindByEmailAsync(User.Email);
                await UserManager.SetRoleAsync(User, SelectedRole);
                CurrentRole = SelectedRole;
                AddSuccess($"Змінено роль користувача {User.UserName} на {SelectedRole}.");
                await OnRoleChanged.InvokeDelegateAsync(CurrentRole);
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }
    }
}
