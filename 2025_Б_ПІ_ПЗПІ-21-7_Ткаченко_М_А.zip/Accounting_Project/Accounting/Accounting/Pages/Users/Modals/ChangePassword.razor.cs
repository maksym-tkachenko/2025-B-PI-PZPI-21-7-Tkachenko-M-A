﻿using Accounting.Components;
using Accounting.DAL.Entities.Identity;
using Accounting.Infrastructure;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Forms;
using System.ComponentModel.DataAnnotations;

namespace Accounting.Pages.Users.Modals
{
    public class ChangePasswordModel : NotificationComponent, IDisposable
    {
        public class InputModel
        {
            [Display(Name = "Пароль")]
            [DataType(DataType.Password)]
            [Required(ErrorMessage = "Поле {0} є обов’язковим.")]
            [StringLength(100, ErrorMessage = "Значення {0} має містити щонайменше {2} і не більше {1} символів.", MinimumLength = 6)]
            public string Password { get; set; } = null!;

            [Display(Name = "Підтвердження паролю")]
            [DataType(DataType.Password)]
            [Compare(nameof(Password), ErrorMessage = "Пароль і Підтвердження паролю не співпадають.")]
            public string ConfirmPassword { get; set; } = null!;
        }

        private ValidationMessageStore _validationMessageStore;

        [Parameter] public string UserEmail { get; set; } = null!;
        [Parameter] public EventCallback OnPasswordChanged { get; set; }

        public User User { get; private set; }
        public InputModel Input { get; set; }
        public EditContext EditContext { get; set; }

        public ChangePasswordModel()
        {
            User = new();
            Input = new();
            EditContext = new(Input);
            _validationMessageStore = new(EditContext);
        }

        protected override async Task OnParametersSetAsync()
        {
            try
            {
                User = await UserManager.FindByEmailAsync(UserEmail);
                Input = new();
                EditContext = new(Input);
                _validationMessageStore = new(EditContext);
                EditContext.OnValidationRequested += OnValidationRequested;
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }

        private void OnValidationRequested(object? sender, ValidationRequestedEventArgs e)
        {
            try
            {
                _validationMessageStore.Clear();
                InvokeAsync(async () =>
                {
                    var result = await UserManager.ValidatePasswordAsync(User, Input.Password);
                    if (!result.Succeeded)
                    {
                        foreach (var error in result.Errors)
                        {
                            _validationMessageStore.Add(() => Input.Password, error.Description);
                        }
                    }
                });
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }

        public async Task ChangePasswordAsync()
        {
            try
            {
                if (await UserManager.HasPasswordAsync(User))
                {
                    await UserManager.RemovePasswordAsync(User);
                }

                await UserManager.AddPasswordAsync(User, Input.Password);
                AddSuccess("Пароль успішно змінено.");
                await OnPasswordChanged.InvokeDelegateAsync();
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }

        public void Dispose()
        {
            EditContext.OnValidationRequested -= OnValidationRequested;
        }
    }
}
