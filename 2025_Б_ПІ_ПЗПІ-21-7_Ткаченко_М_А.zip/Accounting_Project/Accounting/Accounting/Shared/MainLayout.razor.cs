﻿using Accounting.BLL.Managers;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Authorization;

namespace Accounting.Shared
{
    public class MainLayoutComponent : LayoutComponentBase
    {
        private const string _loginUrl = "/Identity/Account/Login";

        [Inject] private UserManager UserManager { get; set; } = null!;
        [Inject] private NavigationManager NavigationManager { get; set; } = null!;
        [CascadingParameter] public Task<AuthenticationState> AuthState { get; set; } = null!;

        protected override async Task OnInitializedAsync()
        {
            try
            {
                var authState = await AuthState;
                var currentUser = await UserManager.GetUserAsync(authState.User);

                if (currentUser == null)
                {
                    NavigateToLogin();
                }
            }
            catch (Exception)
            {
                NavigateToLogin();
            }
        }

        private void NavigateToLogin()
        {
            if (!NavigationManager.Uri.Contains(_loginUrl))
            {
                NavigationManager.NavigateTo(_loginUrl, true);
            }
        }
    }
}
