﻿using Microsoft.AspNetCore.Components;
using Accounting.Components;
using Accounting.Infrastructure;
using Accounting.ViewServices;
using System.Web;

namespace Accounting.Shared.Common.Modals
{
    public class ModalWindowModel : NotificationComponent
    {
        [Inject] public ICustomJSRuntime JsRuntime { get; set; } = null!;

        [Parameter] public string ModalId { get; set; }
        [Parameter] public string? ModalTitle { get; set; }
        [Parameter] public string Style { get; set; } = "modal-dialog modal-xl modal-dialog-centered";
        [Parameter] public bool Show { get; set; }
        [Parameter] public RenderFragment ChildContent { get; set; } = null!;
        [Parameter] public EventCallback<string> OnCanceled { get; set; }

        public bool TitleContainsHTML => ModalTitle != HttpUtility.HtmlEncode(ModalTitle);

        public ModalWindowModel()
        {
            Show = false;
            ModalId = string.Empty;
        }

        public async Task OnClickCancelAsync()
        {
            try
            {
                await OnCanceled.InvokeDelegateAsync(ModalId);
                await CloseModalAsync();
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }

        protected override async Task OnParametersSetAsync()
        {
            try
            {
                if (Show)
                {
                    await OpenModalAsync();
                }
                else
                {
                    await CloseModalAsync();
                }
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }

        private async Task OpenModalAsync()
        {
            try
            {
                await JsRuntime.OpenModalAsync(ModalId);
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }

        private async Task CloseModalAsync()
        {
            try
            {
                await JsRuntime.CloseModalAsync(ModalId);
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }
    }
}
