using Accounting.BLL.Models.Business.Common;
using Accounting.BLL.Models.Filters.Common;
using Accounting.DAL.Entities.Identity;
using Accounting.ViewServices;
using Microsoft.AspNetCore.Components;
using System.Linq.Expressions;
using System.Reflection;

namespace Accounting.Components
{
    public abstract class ItemsListComponent<TEntity, TFilter> : NotificationComponent
        where TEntity : class
        where TFilter : BaseFilter, new()
    {
        protected User _currentUser = null!;
        protected string _currentRole = null!;

        [Inject] protected ICustomJSRuntime JsRuntime { get; set; } = null!;

        public TFilter Filter { get; protected set; } = new();
        public ItemsList<TEntity> ItemsList { get; protected set; } = new();

        public ItemsListComponent(string title)
            : base(title)
        {
        }

        public virtual Task OnAdded(TEntity entity)
        {
            return ReloadItems();
        }

        public virtual Task OnEdited(TEntity entity)
        {
            return ReloadItems();
        }

        public virtual Task OnDeleted(TEntity entity)
        {
            return ReloadItems();
        }

        public virtual Task OnPageChanged(int pageNumber)
        {
            Filter.PageNumber = pageNumber;
            return OnFilterChanged();
        }

        public Task OnChangeFilter<TValue>(Expression<Func<TFilter, TValue>> expression, TValue value)
        {
            var memberSelectorExpression = expression.Body as MemberExpression;
            if (memberSelectorExpression != null)
            {
                var property = memberSelectorExpression.Member as PropertyInfo;
                if (property != null)
                {
                    property.SetValue(Filter, value, null);
                }
            }

            return OnFilterChanged();
        }

        public Task OnFilterChanged()
        {
            return ReloadItems();
        }

        protected virtual Task LoadItemsAsync()
        {
            return Task.CompletedTask;
        }

        protected override async Task OnInitializedAsync()
        {
            try
            {
                _currentUser = await GetCurrentUserAsync();
                _currentRole = await UserManager.GetRoleAsync(_currentUser);
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }

        protected override async Task OnParametersSetAsync()
        {
            try
            {
                await LoadItemsAsync();
            }
            catch (Exception ex)
            {
                AddError(ex);
            }
        }

        private Task ReloadItems()
        {
            try
            {
                return InvokeAsync(async () =>
                {
                    await LoadItemsAsync();
                    StateHasChanged();
                });
            }
            catch (Exception ex)
            {
                AddError(ex);
            }

            return Task.CompletedTask;
        }
    }
}
