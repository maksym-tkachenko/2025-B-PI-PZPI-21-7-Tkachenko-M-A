﻿namespace Accounting.Components.Enums
{
    public enum ModalType
    {
        None,
        AddModal,
        EditModal,
        AddOrEditModal,
        DeleteModal
    }
}
