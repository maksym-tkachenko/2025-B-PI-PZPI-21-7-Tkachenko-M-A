﻿namespace Accounting.Models.Notifications
{
    public enum MessageColor
    {
        Primary,
        Secondary,
        Dark,
        Light,
        Success,
        Danger,
        Warning,
        Info
    }
}
