﻿using Microsoft.AspNetCore.Components;
using System.ComponentModel;

namespace Accounting.ViewServices
{
    public interface ITitleService : INotifyPropertyChanged
    {
        string Title { get; set; }

        MarkupString TitleHTML { get; }

        bool ContainsHTML { get; }
    }
}
