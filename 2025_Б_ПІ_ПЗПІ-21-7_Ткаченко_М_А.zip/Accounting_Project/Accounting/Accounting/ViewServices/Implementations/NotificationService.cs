﻿using System.Timers;
using Accounting.Models.Notifications;

namespace Accounting.ViewServices.Implementations
{
    public class NotificationService : INotificationService
    {
        private readonly List<Notification> _notifications;
        private readonly System.Timers.Timer _timer;

        public event EventHandler? NotificationsChanged;
        public event EventHandler? NotificationTimerElapsed;

        public bool HasNotification => _notifications.Count > 0;

        public NotificationService()
        {
            _notifications = new List<Notification>();
            _timer = new()
            {
                Interval = 1000,
                AutoReset = true
            };
            _timer.Elapsed += TimerElapsed;
            _timer.Start();
        }

        public List<Notification> GetNotifications()
        {
            ClearBurntNotification();
            return _notifications;
        }

        public void AddNotification(Notification notification)
        {
            _notifications.Clear();
            _notifications.Add(notification);
            NotificationsChanged?.Invoke(this, EventArgs.Empty);
        }

        public void ClearNotification(Notification notification)
        {
            if (_notifications.Contains(notification))
            {
                _notifications.Remove(notification);
                if (!ClearBurntNotification())
                {
                    NotificationsChanged?.Invoke(this, EventArgs.Empty);
                }
            }
        }

        public void Dispose()
        {
            if (_timer is not null)
            {
                _timer.Elapsed += TimerElapsed;
                _timer.Stop();
            }
        }

        private bool ClearBurntNotification()
        {
            var notificationsToDelete = _notifications.Where(item => item.IsBurnt).ToList();
            if (notificationsToDelete is not null && notificationsToDelete.Count > 0)
            {
                notificationsToDelete.ForEach(toast => _notifications.Remove(toast));
                NotificationsChanged?.Invoke(this, EventArgs.Empty);
                return true;
            }

            return false;
        }

        private void TimerElapsed(object? sender, ElapsedEventArgs e)
        {
            ClearBurntNotification();
            NotificationTimerElapsed?.Invoke(this, EventArgs.Empty);
        }
    }
}
