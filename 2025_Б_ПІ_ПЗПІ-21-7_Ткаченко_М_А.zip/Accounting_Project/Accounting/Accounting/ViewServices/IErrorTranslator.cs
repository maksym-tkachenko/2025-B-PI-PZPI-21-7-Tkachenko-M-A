﻿namespace Accounting.ViewServices
{
    public interface IErrorTranslator
    {
        string this[Exception ex] { get; }

        string this[string message] { get; }
    }
}
