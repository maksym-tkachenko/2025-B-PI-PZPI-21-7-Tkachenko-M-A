﻿using Microsoft.AspNetCore.Components;

namespace Accounting.Infrastructure
{
    public static class Extensions
    {
        public static async Task InvokeDelegateAsync<TValue>(this EventCallback<TValue> eventCallback, TValue? value)
        {
            if (eventCallback.HasDelegate)
            {
                await eventCallback.InvokeAsync(value);
            }
        }

        public static async Task InvokeDelegateAsync(this EventCallback eventCallback)
        {
            if (eventCallback.HasDelegate)
            {
                await eventCallback.InvokeAsync();
            }
        }

        public static string? GetString(this ChangeEventArgs changeEventArgs)
        {
            return changeEventArgs?.Value?.ToString();
        }

        public static int? GetNullableInt(this ChangeEventArgs changeEventArgs)
        {
            if (Int32.TryParse(changeEventArgs?.Value?.ToString(), out int result))
            {
                return result;
            }

            return null;
        }

        public static double? GetNullableDouble(this ChangeEventArgs changeEventArgs)
        {
            if (Double.TryParse(changeEventArgs?.Value?.ToString(), out double result))
            {
                return result;
            }

            return null;
        }

        public static bool? GetNullableBool(this ChangeEventArgs changeEventArgs)
        {
            if (Boolean.TryParse(changeEventArgs?.Value?.ToString(), out bool result))
            {
                return result;
            }

            return null;
        }

        public static TEnum? GetNullableEnum<TEnum>(this ChangeEventArgs changeEventArgs) where TEnum : struct
        {
            if (Enum.TryParse(changeEventArgs?.Value?.ToString(), out TEnum result))
            {
                return result;
            }

            return null;
        }

        public static DateTime? GetDateTimeOrDefault(this ChangeEventArgs changeEventArgs)
        {
            if (DateTime.TryParse(changeEventArgs?.Value?.ToString(), out DateTime result))
            {
                return result;
            }

            return null;
        }
    }
}
