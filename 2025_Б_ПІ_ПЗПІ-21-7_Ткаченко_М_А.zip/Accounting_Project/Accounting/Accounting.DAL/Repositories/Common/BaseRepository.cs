﻿using Accounting.DAL.EF;
using Microsoft.EntityFrameworkCore;

namespace Accounting.DAL.Repositories.Common
{
    abstract class BaseRepository
    {
        protected readonly IDbContextFactory<AccountingDbContext> _contextFactory;

        public BaseRepository(IDbContextFactory<AccountingDbContext> contextFactory)
        {
            _contextFactory = contextFactory;
        }
    }
}
