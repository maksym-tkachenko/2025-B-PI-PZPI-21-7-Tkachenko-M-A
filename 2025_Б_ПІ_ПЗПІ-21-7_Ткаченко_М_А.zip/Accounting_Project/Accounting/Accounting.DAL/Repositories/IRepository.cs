﻿using System.Linq.Expressions;

namespace Accounting.DAL.Repositories
{
    public interface IRepository<TEntity> where TEntity : class
    {
        Task<List<TEntity>> GetAllAsync();

        Task<List<TEntity>> GetAllAsync(Expression<Func<TEntity, bool>> predicate);

        Task<List<TEntity>> GetAllAsync(Expression<Func<TEntity, bool>> predicate, string[] includeProperties);

        Task<List<TEntity>> GetAllAsync(Expression<Func<TEntity, bool>>[] predicates,
            Func<IQueryable<TEntity>, IOrderedQueryable<TEntity>>? orderBy,
            params string[] includeProperties);

        Task<List<TEntity>> GetAllAsync(int skipCount, int takeCount,
            Func<IQueryable<TEntity>, IOrderedQueryable<TEntity>>? orderBy,
            params Expression<Func<TEntity, bool>>[] predicates);

        Task<List<TEntity>> GetAllAsync(int skipCount, int takeCount,
           Func<IQueryable<TEntity>, IOrderedQueryable<TEntity>>? orderBy,
           string[] includeProperties,
           params Expression<Func<TEntity, bool>>[] predicates);

        Task<List<TEntity>> GetLatestByDateAsync(Expression<Func<TEntity, bool>> predicate, Expression<Func<TEntity, DateTime>> keySelector);

        Task<int> GetCountAsync(params Expression<Func<TEntity, bool>>[] predicates);

        Task<int> GetGroupsCountAsync<TKey>(Expression<Func<TEntity, bool>>[] predicates, Expression<Func<TEntity, TKey>> groupBy);

        Task<TEntity?> GetFirstOrDefaultAsync(Expression<Func<TEntity, bool>>? predicate = null);

        Task<TEntity> GetByIdAsync(int id);

        Task<TEntity> GetByIdAsync(int id, params string[] includeProperties);

        Task<TEntity> GetByIdAsync(int id, bool withAllProperties);

        Task<TEntity> InsertAsync(TEntity entity);

        Task<TEntity> UpdateAsync(TEntity entityToUpdate);

        Task<TEntity> DeleteAsync(int id);

        Task<List<TEntity>> DeleteRangeAsync(Expression<Func<TEntity, bool>> predicate);
    }
}
