﻿using Accounting.DAL.Entities.Identity;
using Microsoft.AspNetCore.Identity;

namespace Accounting.DAL.EF.Validators
{
    public class PasswordValidator : IPasswordValidator<User>
    {
        public Task<IdentityResult> ValidateAsync(UserManager<User> manager, User user, string password)
        {
            return Task.FromResult(IdentityResult.Success);
        }
    }
}
