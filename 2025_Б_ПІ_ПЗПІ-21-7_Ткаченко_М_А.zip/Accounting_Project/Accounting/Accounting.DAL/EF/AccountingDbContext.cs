﻿using Accounting.DAL.Entities;
using Accounting.DAL.Entities.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace Accounting.DAL.EF
{
    public class AccountingDbContext : IdentityDbContext<User, Role, int, UserClaim, UserRole, UserLogin, RoleClaim, UserToken>
    {
        public DbSet<Enterprise> Enterprises { get; set; } = null!;
        public DbSet<Ownership> Ownerships { get; set; } = null!;
        public DbSet<Tax> Taxes { get; set; } = null!;

        public AccountingDbContext(DbContextOptions<AccountingDbContext> options)
            : base(options)
        {
            //uncomment if you want automatic update database
            //Database.Migrate();
        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            builder.Entity<User>(b => b.HasMany(e => e.UserRoles).WithOne(e => e.User).HasForeignKey(ur => ur.UserId).IsRequired());
            builder.Entity<Role>(b => b.HasMany(e => e.UserRoles).WithOne(e => e.Role).HasForeignKey(ur => ur.RoleId).IsRequired());

            //Auto Include Properties
            builder.Entity<Enterprise>().Navigation(e => e.User).AutoInclude();
            builder.Entity<Enterprise>().Navigation(e => e.Ownerships).AutoInclude();

            builder.Entity<Ownership>().Navigation(o => o.Enterprise).AutoInclude();
            builder.Entity<Ownership>().Navigation(o => o.Tax).AutoInclude();

            AddDefaultAdmin(builder);
        }

        private void AddDefaultAdmin(ModelBuilder builder)
        {
            var adminRole = new Role()
            {
                Id = 1,
                ConcurrencyStamp = "c30f2907-b1df-49cd-9bc5-0efa039ba9ae",
                Name = Entities.Constants.Roles.Admin,
                NormalizedName = Entities.Constants.Roles.Admin.ToUpper()
            };

            var userRole = new Role()
            {
                Id = 2,
                ConcurrencyStamp = "c30f2907-b1df-49cd-9bc5-0efa039ba9aa",
                Name = Entities.Constants.Roles.User,
                NormalizedName = Entities.Constants.Roles.User.ToUpper()
            };

            var admin = new User()
            {
                Id = 1,
                UserName = "admin@gmail.com",
                NormalizedUserName = "ADMIN@GMAIL.COM",
                Email = "admin@gmail.com",
                NormalizedEmail = "ADMIN@GMAIL.COM",
                PasswordHash = "AQAAAAEAACcQAAAAEOvStY69qPpyG3M1Jzr6D0W0Vk0YlZeK1Pvwo+/4MDhl1N+513DvpoJ7iKZPjHCrlQ==", //12345678Aa!
                SecurityStamp = "OGV2JH6BM27RUQFSQDOXDM2WO7EN4F7S",
                ConcurrencyStamp = "562428c2-5d6b-40a9-a0a6-0665802ede1d"
            }; 
            
            var adminWithRole = new UserRole()
            {
                RoleId = adminRole.Id,
                UserId = admin.Id
            };

            builder.Entity<Role>().HasData(adminRole);
            builder.Entity<Role>().HasData(userRole);

            builder.Entity<User>().HasData(admin);
            builder.Entity<UserRole>().HasData(adminWithRole);
        }
    }
}
