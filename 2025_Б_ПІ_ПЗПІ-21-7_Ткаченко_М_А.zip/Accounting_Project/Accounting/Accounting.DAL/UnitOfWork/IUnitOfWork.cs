﻿using Accounting.DAL.Entities;
using Accounting.DAL.Entities.Identity;
using Accounting.DAL.Repositories;

namespace Accounting.DAL.UnitOfWork
{
    public interface IUnitOfWork
    {
        IRepository<Enterprise> Enterprises { get; }

        IRepository<Ownership> Ownerships { get; }

        IRepository<Tax> Taxes { get; }

        IRepository<User> Users { get; }

        TRepository GetTRepository<TRepository>();
    }
}
