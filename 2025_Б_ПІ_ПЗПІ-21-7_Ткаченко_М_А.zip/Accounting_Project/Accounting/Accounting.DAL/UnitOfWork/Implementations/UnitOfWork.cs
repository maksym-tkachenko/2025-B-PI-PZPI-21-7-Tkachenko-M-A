﻿using Accounting.DAL.EF;
using Accounting.DAL.Entities;
using Accounting.DAL.Entities.Identity;
using Accounting.DAL.Repositories;
using Accounting.DAL.Repositories.Common;
using Microsoft.EntityFrameworkCore;

namespace Accounting.DAL.UnitOfWork.Implementations
{
    class UnitOfWork : IUnitOfWork
    {
        private readonly IDbContextFactory<AccountingDbContext> _contextFactory;

        public IRepository<Enterprise> Enterprises => new Repository<Enterprise>(_contextFactory);

        public IRepository<Ownership> Ownerships => new Repository<Ownership>(_contextFactory);

        public IRepository<Tax> Taxes => new Repository<Tax>(_contextFactory);

        public IRepository<User> Users => new Repository<User>(_contextFactory);

        public UnitOfWork(IDbContextFactory<AccountingDbContext> contextFactory)
        {
            _contextFactory = contextFactory;
        }

        public TRepository GetTRepository<TRepository>()
        {
            Type tRepository = typeof(TRepository);
            var repositoryPI = this.GetType().GetProperties().FirstOrDefault(t => t.PropertyType == tRepository);

            if (repositoryPI == null)
                throw new Exception("TRepository not exist");

            return (TRepository)repositoryPI.GetValue(this, null)!;
        }
    }
}
