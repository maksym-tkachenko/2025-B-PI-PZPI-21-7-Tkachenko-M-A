﻿using System.ComponentModel.DataAnnotations;

namespace Accounting.DAL.Entities.Enums
{
    public enum OwnershipType
    {
        [Display(Name = "-")]
        None,
        [Display(Name = "Будівля")]
        Building,
        [Display(Name = "Машина")]
        Machine,
        [Display(Name = "Оборудовання")]
        Equipment,
        [Display(Name = "Інше")]
        Other
    }
}
