﻿using System.ComponentModel.DataAnnotations;

namespace Accounting.DAL.Entities.Enums
{
    public enum TaxType
    {
        [Display(Name = "-")]
        None,
        [Display(Name = "Процент")]
        Percent,
        [Display(Name = "Фіксована сума")]
        Fixed
    }
}
