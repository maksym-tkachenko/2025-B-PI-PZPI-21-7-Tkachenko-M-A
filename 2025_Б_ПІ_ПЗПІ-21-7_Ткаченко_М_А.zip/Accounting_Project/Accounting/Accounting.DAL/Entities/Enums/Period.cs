﻿using System.ComponentModel.DataAnnotations;

namespace Accounting.DAL.Entities.Enums
{
    public enum Period
    {
        [Display(Name = "-")]
        None,
        [Display(Name = "День")]
        Day,
        [Display(Name = "Місяць")]
        Month,
        [Display(Name = "Рік")]
        Year
    }
}
