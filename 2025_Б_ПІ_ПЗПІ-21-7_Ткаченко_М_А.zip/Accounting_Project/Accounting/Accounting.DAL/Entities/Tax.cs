﻿using Accounting.DAL.Entities.Common;
using Accounting.DAL.Entities.Enums;
using Accounting.DAL.Infrastructure;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Accounting.DAL.Entities
{
    public class Tax : BaseEntity
    {
        [Display(Name = "Тип")]
        [Range(1, int.MaxValue, ErrorMessage = "{0} має бути від {1} до {2}.")]
        public TaxType Type { get; set; }

        [Display(Name = "Період")]
        [Range(1, int.MaxValue, ErrorMessage = "{0} має бути від {1} до {2}.")]
        public Period Period { get; set; }

        [Display(Name = "Значення")]
        [Column(TypeName = "money")]
        [Range(0, 922337203685477.58, ErrorMessage = "{0} має бути від {1} до {2}.")]
        public decimal Value { get; set; }

        public List<Ownership> Ownerships { get; set; } = new();

        public override string ToString()
        {
            string result = Type.DisplayName() + " " + Period.DisplayName() + " " + Value;

            if (Type == TaxType.Fixed)
            {
                result += " грн";
            }

            if (Type == TaxType.Percent)
            {
                result += " %";
            }

            return result;
        }
    }
}
