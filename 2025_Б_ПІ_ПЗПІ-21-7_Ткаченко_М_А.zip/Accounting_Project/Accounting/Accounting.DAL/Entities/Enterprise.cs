﻿using Accounting.DAL.Entities.Common;
using Accounting.DAL.Entities.Identity;
using System.ComponentModel.DataAnnotations;

namespace Accounting.DAL.Entities
{
    public class Enterprise : BaseEntity
    {
        [Display(Name = "Назва")]
        [MaxLength(256, ErrorMessage = "{0} має бути коротшим за {1} символів.")]
        public string Name { get; set; } = null!;

        [Display(Name = "Користувач")]
        [Range(1, int.MaxValue, ErrorMessage = "{0} має бути від {1} до {2}.")]
        public int UserId { get; set; }

        [Display(Name = "Користувач")]
        public User User { get; set; } = null!;

        public List<Ownership> Ownerships { get; set; } = new();
    }
}
