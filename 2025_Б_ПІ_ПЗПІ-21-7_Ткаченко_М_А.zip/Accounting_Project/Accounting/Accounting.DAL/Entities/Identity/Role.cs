﻿using Microsoft.AspNetCore.Identity;
using System.Collections.ObjectModel;

namespace Accounting.DAL.Entities.Identity
{
    public class Role : IdentityRole<int>
    {
        public virtual ICollection<UserRole> UserRoles { get; set; } = new Collection<UserRole>();
    }
}
