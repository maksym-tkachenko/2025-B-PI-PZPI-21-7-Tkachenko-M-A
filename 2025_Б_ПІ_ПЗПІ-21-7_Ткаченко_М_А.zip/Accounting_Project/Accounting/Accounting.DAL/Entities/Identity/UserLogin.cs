﻿using Microsoft.AspNetCore.Identity;

namespace Accounting.DAL.Entities.Identity
{
    public class UserLogin : IdentityUserLogin<int>
    {
    }
}
