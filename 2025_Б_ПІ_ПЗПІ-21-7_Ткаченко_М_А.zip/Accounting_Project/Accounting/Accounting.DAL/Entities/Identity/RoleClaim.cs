﻿using Microsoft.AspNetCore.Identity;

namespace Accounting.DAL.Entities.Identity
{
    public class RoleClaim : IdentityRoleClaim<int>
    {
    }
}
