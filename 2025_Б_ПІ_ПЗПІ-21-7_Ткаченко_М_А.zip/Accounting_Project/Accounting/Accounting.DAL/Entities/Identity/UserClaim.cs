﻿using Microsoft.AspNetCore.Identity;

namespace Accounting.DAL.Entities.Identity
{
    public class UserClaim : IdentityUserClaim<int>
    {
    }
}
