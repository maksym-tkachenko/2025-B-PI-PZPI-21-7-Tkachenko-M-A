﻿using Microsoft.AspNetCore.Identity;

namespace Accounting.DAL.Entities.Identity
{
    public class UserToken : IdentityUserToken<int>
    {
    }
}
