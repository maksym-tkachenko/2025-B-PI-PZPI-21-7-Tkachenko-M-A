﻿using Microsoft.AspNetCore.Identity;
using System.Collections.ObjectModel;

namespace Accounting.DAL.Entities.Identity
{
    public class User : IdentityUser<int>
    {
        public virtual ICollection<UserRole> UserRoles { get; set; } = new Collection<UserRole>();
    }
}
