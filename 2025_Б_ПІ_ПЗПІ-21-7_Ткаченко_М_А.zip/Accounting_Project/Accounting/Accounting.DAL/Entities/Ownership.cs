﻿using Accounting.DAL.Entities.Common;
using Accounting.DAL.Entities.Enums;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Accounting.DAL.Entities
{
    public class Ownership : BaseEntity
    {
        [Display(Name = "Назва")]
        [MaxLength(256, ErrorMessage = "{0} має бути коротшим за {1} символів.")]
        public string Name { get; set; } = null!;

        [Display(Name = "Тип")]
        [Range(1, int.MaxValue, ErrorMessage = "{0} має бути від {1} до {2}.")]
        public OwnershipType Type { get; set; }

        [Display(Name = "Початкова вартість, грн")]
        [Column(TypeName = "money")]
        [Range(0, 922337203685477.58, ErrorMessage = "{0} має бути від {1} до {2}.")]
        public decimal InitialCost { get; set; }

        [Display(Name = "Введення в експлуатацію")]
        public DateTime Commissioning { get; set; } = DateTime.Now;

        [Display(Name = "Періодичність втрати ціни")]
        [Range(1, int.MaxValue, ErrorMessage = "{0} має бути від {1} до {2}.")]
        public Period Period { get; set; }

        [Display(Name = "Втрата ціни, грн")]
        [Column(TypeName = "money")]
        [Range(0, 922337203685477.58, ErrorMessage = "{0} має бути від {1} до {2}.")]
        public decimal LossOfPriceByPeriod { get; set; }

        [Display(Name = "Підприємство")]
        [Range(1, int.MaxValue, ErrorMessage = "{0} має бути від {1} до {2}.")]
        public int EnterpriseId { get; set; }

        [Display(Name = "Підприємство")]
        public Enterprise Enterprise { get; set; } = null!;

        [Display(Name = "Податки")]
        [Range(1, int.MaxValue, ErrorMessage = "{0} має бути від {1} до {2}.")]
        public int TaxId { get; set; }

        [Display(Name = "Податки")]
        public Tax Tax { get; set; } = null!;
    }
}
