﻿using Accounting.DAL.EF;
using Accounting.DAL.EF.Localizers;
using Accounting.DAL.EF.Validators;
using Accounting.DAL.Entities.Identity;
using Accounting.DAL.UnitOfWork;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace Accounting.DAL.Infrastructure
{
    public static class DependencyInjections
    {
        public static IdentityBuilder ConfigureDAL(this IServiceCollection services, string connectionString)
        {
            return services
                .AddDbContextFactory<AccountingDbContext>(options => options.UseSqlServer(connectionString))
                .AddScoped<IUnitOfWork, UnitOfWork.Implementations.UnitOfWork>()
                .ConfigureIdentity();
        }

        private static IdentityBuilder ConfigureIdentity(this IServiceCollection services)
        {
            return services.AddIdentity<User, Role>(options =>
            {
                options.SignIn.RequireConfirmedAccount = false;
            })
                .AddDefaultTokenProviders()
                .AddErrorDescriber<LocalizedIdentityErrorDescriber>()
                .AddEntityFrameworkStores<AccountingDbContext>()
                .AddUserValidator<UserValidator>()
                .AddPasswordValidator<PasswordValidator>();
        }
    }
}
