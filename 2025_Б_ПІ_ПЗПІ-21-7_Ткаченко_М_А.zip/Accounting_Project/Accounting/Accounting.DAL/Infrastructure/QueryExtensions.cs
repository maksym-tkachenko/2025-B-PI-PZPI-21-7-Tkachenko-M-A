﻿using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;

namespace Accounting.DAL.Infrastructure
{
    static class QueryExtensions
    {
        public static IQueryable<TEntity> Filter<TEntity>(this IQueryable<TEntity> query,
            params Expression<Func<TEntity, bool>>[] filters) where TEntity : class
        {
            if (filters.Length > 0)
            {
                foreach (var filter in filters)
                {
                    query = query.Where(filter);
                }
            }

            return query;
        }

        public static IQueryable<TEntity> IncludeProperties<TEntity>(this IQueryable<TEntity> query,
            string[] includeProperties) where TEntity : class
        {
            foreach (var property in includeProperties)
            {
                query = query.Include(property);
            }

            return query;
        }

        public static IQueryable<TEntity> Order<TEntity>(this IQueryable<TEntity> query,
            Func<IQueryable<TEntity>, IOrderedQueryable<TEntity>>? orderBy) where TEntity : class
        {
            if (orderBy != null)
            {
                query = orderBy(query);
            }

            return query;
        }

        public static IQueryable<TEntity> SkipItems<TEntity>(this IQueryable<TEntity> query,
            int skipItems) where TEntity : class
        {
            if (skipItems > 0)
            {
                return query.Skip(skipItems);
            }

            return query;
        }

        public static IQueryable<TEntity> TakeItems<TEntity>(this IQueryable<TEntity> query,
            int takeItems) where TEntity : class
        {
            return query.Take(takeItems);
        }
    }
}
